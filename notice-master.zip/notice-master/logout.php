<?php


unset( $_SESSION['is_logged']);

header("location:Noticefrontend.php");

?>